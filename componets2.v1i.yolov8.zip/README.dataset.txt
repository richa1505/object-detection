# componets2 > 2025-01-11 12:24pm
https://universe.roboflow.com/componets1/componets2

Provided by a Roboflow user
License: CC BY 4.0

